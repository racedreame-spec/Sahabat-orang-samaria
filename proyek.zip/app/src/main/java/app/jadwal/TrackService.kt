package app.jadwal

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import java.util.Locale

class TrackService : Service() {
    private lateinit var lm: LocationManager
    private val ls = LL { l -> onLoc(l) }

    private fun p() = getSharedPreferences("trk", Context.MODE_PRIVATE)
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        lm = getSystemService(LocationManager::class.java)
        if (i?.action == "STOP") { stopTrack(); return START_NOT_STICKY }
        Notif.channels(this)
        val stop = PendingIntent.getService(this, 1, Intent(this, TrackService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "track").setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Pelacakan perjalanan aktif").setContentText("Mencatat tempat dan lama berhenti").setOngoing(true)
            .setContentIntent(open).addAction(Notification.Action.Builder(0, "Hentikan", stop).build()).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(77, n)
        } catch (e: Exception) { p().edit().putBoolean("on", false).apply(); stopSelf(); return START_NOT_STICKY }
        if (i != null) close()
        p().edit().putBoolean("on", true).apply()
        lm.removeUpdates(ls)
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 60000L, 0f, ls)
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 60000L, 0f, ls)
        } catch (e: SecurityException) { stopTrack(); return START_NOT_STICKY }
        return START_STICKY
    }

    private fun onLoc(l: Location) {
        if (l.accuracy > 100f) return
        val pr = p()
        val t = System.currentTimeMillis()
        if (pr.getLong("st", 0L) == 0L) { open(l, t); return }
        val la = (pr.getString("alat", "0") ?: "0").toDouble()
        val lo = (pr.getString("alng", "0") ?: "0").toDouble()
        val d = FloatArray(1)
        Location.distanceBetween(la, lo, l.latitude, l.longitude, d)
        if (d[0] <= 80f) {
            val n = pr.getInt("n", 1) + 1
            pr.edit().putString("alat", (la + (l.latitude - la) / n).toString()).putString("alng", (lo + (l.longitude - lo) / n).toString())
                .putInt("n", n).putLong("last", t).apply()
        } else { close(); open(l, t) }
    }

    private fun open(l: Location, t: Long) {
        p().edit().putString("alat", l.latitude.toString()).putString("alng", l.longitude.toString()).putInt("n", 1).putLong("st", t).putLong("last", t).apply()
    }

    private fun close() {
        val pr = p()
        val st = pr.getLong("st", 0L)
        if (st > 0L) {
            val mins = ((pr.getLong("last", st) - st) / 60000).toInt()
            val la = (pr.getString("alat", "0") ?: "0").toDouble()
            val lo = (pr.getString("alng", "0") ?: "0").toDouble()
            if (mins >= 5) saveVisit(la, lo, st, mins)
        }
        pr.edit().remove("st").remove("alat").remove("alng").remove("n").remove("last").apply()
    }

    private fun saveVisit(la: Double, lo: Double, st: Long, mins: Int) {
        val c = applicationContext
        Thread {
            var name: String? = null
            var best = 80f
            for (q in Places.all(c)) {
                val d = FloatArray(1)
                Location.distanceBetween(la, lo, q.lat, q.lng, d)
                if (d[0] < best) { best = d[0]; name = q.name }
            }
            if (name == null) {
                var nm = "%.4f, %.4f".format(Locale.US, la, lo)
                try {
                    if (Geocoder.isPresent()) {
                        val a = Geocoder(c, Locale("id", "ID")).getFromLocation(la, lo, 1)
                        if (!a.isNullOrEmpty()) nm = a[0].getAddressLine(0) ?: nm
                    }
                } catch (e: Exception) {}
                name = nm
            }
            Places.add(c, Pl(st, la, lo, name ?: "Tempat", mins))
        }.start()
    }

    private fun stopTrack() {
        close()
        p().edit().putBoolean("on", false).apply()
        try { lm.removeUpdates(ls) } catch (e: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        try { lm.removeUpdates(ls) } catch (e: Exception) {}
        super.onDestroy()
    }
}
