package app.jadwal

import android.app.Activity
import android.app.NotificationManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AlarmActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("id", 0L)
        val x = Store.get(this, id)
        val nm = getSystemService(NotificationManager::class.java)
        fun t(q: String, sp: Float, bold: Boolean) = TextView(this).apply {
            text = q; textSize = sp; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            if (bold) setTypeface(null, Typeface.BOLD)
        }
        fun b(q: String, f: () -> Unit) = Button(this).apply { text = q; setOnClickListener { f() } }
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(0xFF14161A.toInt()); setPadding(48, 48, 48, 48)
        }
        l.addView(t(if (x != null) "%02d.%02d".format(x.hour, x.minute) else "", 48f, true))
        l.addView(t(x?.title ?: "Alarm", 24f, false))
        l.addView(b("Selesai") { x?.let { Hist.mark(this, it) }; nm.cancel(id.toInt()); finish() })
        l.addView(b("Tunda 10 menit") { nm.cancel(id.toInt()); Sched.snooze(this, id, 10); finish() })
        setContentView(l)
    }
}
